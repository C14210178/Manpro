This Free Font is part of the Ketoprak font with fewer glyphs. please buy a more complete version for more varied use.

You can support us by buying the license here:
https://s.id/KetoprakFont

Check our premium font bundles
https://pixelsurplus.com/?ref=drmwn

You can send your donation through our Paypal account:
https://www.paypal.me/diqtam

or simply click the Donate Button at the download page

Thanks, You are AWESOME